﻿using System.Net.Mail;
using System.Net;
using Microsoft.AspNetCore.Mvc;

namespace Pedritoautoservis.Controllers
{
    public class CotizacionController : Controller
    {
        [HttpPost]
        [Route("/enviar_cotizacion")]
        public async Task<IActionResult> EnviarCotizacion(string nombre, string correo, string telefono, string servicio, IFormFile imagen, string mensaje)
        {
            try
            {
                // Configuración del correo
                var fromAddress = new MailAddress("chapadavid591@gmail.com", "web_Autoservís");
                var toAddress = new MailAddress("autoservisgas94@gmail.com");
                const string fromPassword = "iocd zlyw ljgy rxzi";
                const string subject = "Nueva solicitud de cotización GLP";

                string body = $"<h3>Datos de una nueva Cotización:</h3>" +
                              $"<p><b>Nombre:</b> {nombre}</p>" +
                              $"<p><b>Correo:</b> {correo}</p>" +
                              $"<p><b>Teléfono:</b> {telefono}</p>" +
                              $"<p><b>Servicio:</b> {servicio}</p>" +
                              $"<p><b>Mensaje:</b> {mensaje}</p>";

                var smtp = new SmtpClient
                {
                    Host = "smtp.gmail.com",
                    Port = 587,
                    EnableSsl = true,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential(fromAddress.Address, fromPassword)
                };

                using (var message = new MailMessage(fromAddress, toAddress)
                {
                    Subject = subject,
                    Body = body,
                    IsBodyHtml = true
                })
                {
                    // Adjuntar imagen si se ha proporcionado
                    if (imagen != null && imagen.Length > 0)
                    {
                        var ms = new MemoryStream();
                        await imagen.CopyToAsync(ms); // ✅ Ahora se usa await
                        ms.Position = 0;

                        var attachment = new Attachment(ms, imagen.FileName);
                        message.Attachments.Add(attachment);
                    }

                    smtp.Send(message);
                }

                // Confirmación al usuario
                ViewBag.MensajeExito = "¡Su cotización fue enviada con éxito! Nos pondremos en contacto pronto.";
                return View("Confirmación");

            }
            catch (Exception ex)
            {
                ViewBag.MensajeError = "Error detallado: " + (ex.InnerException?.Message ?? ex.Message);
                return View("Confirmación");
            }
        }
    }
}
